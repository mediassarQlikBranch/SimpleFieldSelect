define( ["qlik", "jquery", "text!./SimpleFieldStyle.css","text!./datepicker.css","./properties.def","./jquery-ui.min"], 
	function ( qlik, $, cssContent, cssDatepick, propertiesdef ) {
	'use strict';
	$( "<style>" ).html( cssContent ).appendTo( "head" );
	$( "<style>" ).html( cssDatepick ).appendTo( "head" );
	var debug = false;
	
	//If nothing selected but should be
	function checkDefaultValueSelection($element,countselected,layout,self,app){
	  if(debug) console.log('checkin default selection, selected: '+countselected);
	  if (countselected==0 && (layout.props.allwaysOneSelectedDefault != '' || layout.props.selectAlsoThese != '')){
		var defaulttoselect = $element.find( '.defaultelement' );
		var otherdefaultelememnts = $element.find('.otherdefelem');
		 //console.log(otherdefaultelememnts);
		//check if element is found
		//console.log(otherdefaultelememnts);
		if (defaulttoselect.length<1 && otherdefaultelememnts.length<1) {
			if(debug) console.log('Default value was not found' +layout.qInfo.qId);
			return;
		}
		var otherDefaultElementsSelectionStyle = true; //depends on if the main default value is selected
		var valuesToSelect = [];
		if (defaulttoselect.length>0){
			if(debug) console.log('selecting default value');
			if (layout.props.visualizationType=='dropdown'){
			  selectValueInQlik(self, parseInt(defaulttoselect.val(),10) ,layout,app,false); //select here, no other defaults
			} else {
			  //selectValueInQlik(self, parseInt(defaulttoselect.attr( "dval" ),10) ,layout,app,false);
			  valuesToSelect.push( parseInt(defaulttoselect.attr( "dval" ),10) );
			  otherDefaultElementsSelectionStyle = false;
			}
		}
		if (otherdefaultelememnts.length>0){
			if(debug) console.log('selecting other defaults, method: '+otherDefaultElementsSelectionStyle);
			otherdefaultelememnts.each(function(elem){
				//selectValueInQlik(self, parseInt($(this).attr( "dval" ),10) ,layout,app,otherDefaultElementsSelectionStyle);
				valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
			});
		}
		if (valuesToSelect){
			selectValuesInQlik(self, valuesToSelect ,layout,app,false);
		}
	  }
	}
	function selectValueInQlik(self,value,layout,app,selectvalueMethod){ //selectvalueMethod true or false
		if(debug) console.log('set value to index '+value);
		//Variable
		if (layout.props.dimensionIsVariable){
			var valueTxt = layout.props.variableOptionsForValuesArray[ value ];
			//if value is not defined, forexample nothing is selected for variable.
			if (typeof valueTxt == 'undefined' ){
				valueTxt = '';
			}
			if(debug) console.log(' means '+valueTxt+' to variable ' +layout.props.variableName);
			//set variable
			app.variable.setContent(layout.props.variableName, valueTxt);
			//set key value too if defined
			if (layout.props.variableOptionsForKeysArray != [] && layout.props.variableNameForKey && layout.props.variableOptionsForKeysArray[ value ]){
				var keyTxt = layout.props.variableOptionsForKeysArray[ value ];
				if(debug) console.log(' key value '+keyTxt+' to variable ' +layout.props.variableNameForKey);
				app.variable.setContent(layout.props.variableNameForKey, keyTxt);
			}
		//set field
		} else {
			self.backendApi.selectValues( 0, [value], selectvalueMethod );
		}
	}
	function selectValuesInQlik(self,values,layout,app,selectvalueMethod){ //select manyvalues at the same time
		if(debug) console.log('set values to indexes ');
		if(debug) console.log(values);
		self.backendApi.selectValues( 0, values, selectvalueMethod );
	}
	
	return {
		initialProperties: {
			qListObjectDef: {
				qShowAlternatives: true,
				//qFrequencyMode: "V",
				qInitialDataFetch: [{
					qWidth: 2,
					qHeight: 1000
				}],
				qSortByState: 0,
			},
			variableValue: {},
			maxLimitvariableValue: {},
			props: {
				dimensionIsVariable: false
			}
		},
		
		definition: propertiesdef,
		support : {
			snapshot: false,
			export: false,
			exportData : false
		},
		paint: function ( $element,layout ) {
			if (debug){ console.log('start painting');	console.log(layout); }
			
			var self = this, html = "";
			var app = qlik.currApp();
			//change header size
			var headerelement = $element.parent().parent().prev();
			if (layout.props && layout.props.showHeader){
				headerelement.show();
				if (layout.props.headerSize && layout.props.headerSize != '-'){
					headerelement.css('height',layout.props.headerSize+'px');
				}
				if (layout.props.headerBpadding && layout.props.headerBpadding != '-'){
					headerelement.css('padding-bottom',layout.props.headerBpadding+'px');
				}
			} else {
				headerelement.hide();
			}
			//borders and bg
			var articleInnerElement = headerelement.parent();
			var articleElement = articleInnerElement.parent();
			if (layout.props.transparentBackground){
				articleElement.css('background-color','transparent');
				articleInnerElement.css('background-color','transparent');
			} else if (layout.props.specialBackgroundColor){
				articleElement.css('background-color',layout.props.specialBackgroundColor);
				articleInnerElement.css('background-color',layout.props.specialBackgroundColor);
			} else {
				articleElement.css('background-color','');
				articleInnerElement.css('background-color','');
			}
			if (layout.props.noBorders){
				articleElement.css('border-width','0');
			}
			/*if (layout.props.specialFontcolor){
				articleElement.css('color',layout.props.specialFontcolor);
			} else {
				articleElement.css('color','');
			}*/
			//left padding in one qlik theme
			if(layout.props.leftpadding && layout.props.leftpadding != '-'){
				articleInnerElement.css('padding-left',layout.props.leftpadding+'px');
			}
			//padding
			var paddingDivAdded = 0;
			if(layout.props.contentpadding && layout.props.contentpadding != '-'){
				html += '<div style="padding:'+layout.props.contentpadding +'px">';
				paddingDivAdded = 1;
			}
			//extra label
			var labelAdded = 0;
			if(layout.props.inlinelabeltext){
				html += '<label class=inlinelabel><div class="inlinelabeldiv';
				if (layout.props.inlinelabelSetinline){
					html += ' inlinelabeldivInline';
				}
				html += '">'+layout.props.inlinelabeltext+'</div> ';
				labelAdded = 1;
			}
			//change for mobile
			if ($('.smallDevice').length >0){ //$(window).width()<600
				var parent = $element.closest('.qv-gridcell');
				//console.log(parent.html());
				if(layout.props.mobileRemoveZoom){
					parent.find('.transparent-overlay').remove(); //remove mobile zoom haveto
				}
				//set height, default is too high
				if(layout.props.mobileCustomHeightCSS && layout.props.mobileCustomHeightCSS != ''){
					parent.css('height',layout.props.mobileCustomHeightCSS);
				} else {
					parent.css('height','65px');
				}
			}
			
			//hide
			if (layout.props.hideFromSelectionsBar){
				var fieldToHide = layout.props.hideFromSelectionRealField;
				if (fieldToHide == '' || !fieldToHide){
					fieldToHide = layout.qListObject.qDimensionInfo.qGroupFieldDefs[0]; //try this one if not defined.
					if (fieldToHide.slice(0,1)==='='){ //if first letter =
						fieldToHide = fieldToHide.slice(1);
					}
					fieldToHide = fieldToHide.replace(/[\[\]']+/g,''); //reomve []
				}
				//add hide area if needed
				if ($(".hideselstyles").length>0){
					
				} else {
					$('.qv-selections-pager').append('<div style="display:none;" class=hideselstyles></div>');
				}
				if ($('#hid'+fieldToHide).length>0){
					//already hidden
				} else {
					$('.hideselstyles').append('<style id="hid'+fieldToHide+'">.qv-selections-pager li[data-csid="'+ fieldToHide +'"] {display:none;}</style>');
				}
			}
			//Globals CSS mod
			if (layout.props.enableGlobals){
				if ($(".SFSglobalCSS").length>0){
				
				} else {
					articleInnerElement.append('<div style="display:none;" class=SFSglobalCSS></div>');
				}
				var csstxt = '';
				if (layout.props.global_bgcolor){
					csstxt += ' .qv-client.qv-card #qv-stage-container .qvt-sheet { background-color:'+layout.props.global_bgcolor+';}';
				}
				if (layout.props.global_borderwidth && layout.props.global_borderwidth != '-'){
					csstxt += ' .sheet-grid .qv-gridcell:not(.qv-gridcell-empty),.qv-mode-edit .qv-gridcell:not(.qv-gridcell-empty), .sheet-grid :not(.library-dragging)#grid .qv-gridcell.active { border-width:'+layout.props.global_borderwidth+'px;}';
				}
				if (layout.props.global_bordercolor){
					csstxt += ' .sheet-grid .qv-gridcell:not(.qv-gridcell-empty) { border-color:'+layout.props.global_bordercolor+';}';
				}
				
				$(".SFSglobalCSS").html('<style id="">' + csstxt + '</style>');
				//.qv-client.qv-card #qv-stage-container .qvt-sheet
				//$( "<style>" ).html( cssContent ).appendTo( "head" );
			}
			//get variable value
			var varvalue = '';
			if (layout.props.dimensionIsVariable){
				varvalue = layout.variableValue;
				if (debug){ console.log('varvalue from '+layout.props.variableName+' is '); console.log(varvalue); }
			}
			var fontStyleTxt = '';
			if (layout.props.customFontCSS && layout.props.customFontCSS != ''){
				fontStyleTxt = ' font:'+layout.props.customFontCSS+';';
			}
			var elementStyleCSS = '';
			if (layout.props.customStyleCSS && layout.props.customStyleCSS != ''){
				elementStyleCSS = ' '+layout.props.customStyleCSS+';';
			}
			var elementExtraAttribute = '';
			if (layout.props.customElementAttribute && layout.props.customElementAttribute != ''){
				elementExtraAttribute = ' '+layout.props.customElementAttribute+' ';
			}
			var elementExtraClass = '';
			if (layout.props.customElementClass && layout.props.customElementClass != ''){
				elementExtraClass = ' '+layout.props.customElementClass+' ';
			}
			var fontsizechanges = '';
			if (layout.props.fontsizeChange && layout.props.fontsizeChange != ''){
				fontsizechanges = ' font-size:'+layout.props.fontsizeChange+'%;';
			}
			//if date select to variable
			if (layout.props.variableIsDate && layout.props.dimensionIsVariable){
				if (layout.props.variableName){
					if (debug){ console.log('alkuarvo ' + layout.props.variableName); console.log(app.variable.getContent(layout.props.variableName)); }
					
					html += '<input type=text title="Click to select date" class="pickdate'+elementExtraClass+'" value="'+varvalue+'" style="width:6em; max-width:80%;'+fontsizechanges+fontStyleTxt+elementStyleCSS+'"' +elementExtraAttribute+ '/>';
					if(labelAdded) html += '</label>';
					if (layout.props.helptext){
						html += '<div class="sfs_helptxt">'+ layout.props.helptext + '</div>';
					}
					if(paddingDivAdded) html += '</div>';
					$element.html( html );
					
					var datepickElement = $element.find( '.pickdate' );
					datepickElement.datepicker({
						dateFormat: layout.props.dateformat,
						changeMonth: true,
						changeYear: true,
						showOn: "both",
						firstDay:1,
						constrainInput: true
					});
					 //dates limited?
					//if (debug) {console.log(layout.props.maxLimitvariable);}
					if (layout.props.maxLimitvariable && layout.props.maxLimitvariable && layout.props.maxLimitvariable != '-'){
						if (debug){ console.log('Limiting days to '); console.log(layout.props.maxLimitvariable); }
						var parsedDate = $.datepicker.parseDate(layout.props.dateformat, layout.props.maxLimitvariable);
						datepickElement.datepicker( "option", "maxDate", parsedDate );
					}
					$element.find( '.pickdate' ).on( 'change', function () {
						var newval = $(this).val();
						if(debug) console.log('NEW '+newval + ' to '+layout.props.variableName);
						app.variable.setContent(layout.props.variableName, newval);
					});
				}
			//not date select:
			} else {
			
			
				html += '<div class="checkboxgroup"';
				if (layout.props.hovertitletext && layout.props.hovertitletext != ''){
					html += ' title="'+layout.props.hovertitletext.replace(/\"/g,'&quot;')+'"'; //escape quotas!!
				}
				html += '>';
				var countselected = 0;
				var stylechanges = ' style="'+fontsizechanges+fontStyleTxt;
				stylechanges += '"';
				if (layout.props.visualizationType=='vlist'){
					html += '<ul'+stylechanges+'>';
				}else if (layout.props.visualizationType=='hlist'){
					var roundcornerClass=' rcorners';
					if (layout.props.hlistRoundedcorners===false){
						roundcornerClass='';
					}
					var rmarginclass = ' rmargin1';
					if (layout.props.hlistMarginBetween >= 0){ //its defined
						rmarginclass = ' rmargin'+layout.props.hlistMarginBetween;
					}
					var displayastableClass = '';
					if (layout.props.hlistShowAsTable){
						displayastableClass = ' ulastable'
					}
					html += '<ul class="horizontal'+roundcornerClass+rmarginclass+displayastableClass+'" '+stylechanges+'>';
				} else if (layout.props.visualizationType=='checkbox' || layout.props.visualizationType=='radio'){
					html += '<div '+stylechanges+'>';
				} else if (layout.props.visualizationType=='dropdown'){
					html += '<select class="dropdownsel'+elementExtraClass+'" '+stylechanges+'' +elementExtraAttribute+ '>';
				} else if (layout.props.visualizationType=='btn'){
					html += '<div '+stylechanges+'>';
				} else {
					html += 'Select visualization type';
				}
				//border color style
				var bordercolorstyle = '';
				if (layout.props.color_border && layout.props.color_border != ''){
					bordercolorstyle = ' border-color:'+layout.props.color_border+';';
				}
				//print elements
				var optionsforselect = [];
				if (layout.props.dimensionIsVariable){
					//generate variable options from field
					if (debug) console.log('variable value '+varvalue);
					if (!layout.props.variableOptionsForValues){
						html += 'Set variable options or enable date selector';
					}
					var splitted = layout.props.variableOptionsForValues.split(";");
					var varindex = 0; //index is used to access variable
					layout.props.variableOptionsForValuesArray = [];
					layout.props.variableOptionsForKeysArray = [];
					splitted.forEach(function(opt){
						var qState = 'O';
						//if values match with current, mark selected
						if (varvalue == opt) {
							qState = 'S'; 
						} //build qlik style object for printing
						optionsforselect.push( [{qState:qState, qText:opt, qElemNumber:varindex}] );
						layout.props.variableOptionsForValuesArray.push(opt); //when setting variable, take value from here.
						varindex += 1;
					});
					if (debug){ console.log(layout.props.variableOptionsForValues); }
					//if separate Keys variable is defined:
					var varKeyindex = 0;
					if (layout.props.dimensionIsVariable && layout.props.variableOptionsForKeys != ''){
						splitted = layout.props.variableOptionsForKeys.split(";");
						splitted.forEach(function(opt){
							layout.props.variableOptionsForKeysArray.push(opt); //when setting variable, take value from here.
							varKeyindex += 1;
						});
						if (varindex != varKeyindex){
							console.log('variable values and key options do not match. Values: '+varindex + ' vs. keys: '+varKeyindex);
							layout.props.variableOptionsForKeysArray = []; //reset array
						}
					}
					
				//if not variable:
				} else {
					optionsforselect = layout.qListObject.qDataPages[0].qMatrix;
				}
				//dropdown default option
				if (layout.props.visualizationType=='dropdown' && layout.props.dropdownValueForNoSelect && layout.props.dropdownValueForNoSelect != ''){
					html += '<option class="state0" value=""> ' + layout.props.dropdownValueForNoSelect;
					html += '</option>';
				}
				//fetch other default values
				var otherDefaultValues = [];
				if (!layout.props.selectOnlyOne && layout.props.selectAlsoThese && layout.props.selectAlsoThese != '' && !layout.props.dimensionIsVariable &&
						layout.props.visualizationType!='dropdown' && layout.props.visualizationType!='btn' && layout.props.visualizationType!='radio'){
					otherDefaultValues = layout.props.selectAlsoThese.split(";");
					//console.log(otherDefaultValues);
				}
				//paint options
				optionsforselect.forEach( function ( row ) {
					if (layout.props.hidePassiveItems && !layout.props.dimensionIsVariable && row[0].qState === 'X'){ //if passive hiding enabled
						return; //exit current function
					}
					//var elementid = layout.qInfo.qId+''+row[0].qElemNumber;
					var defaultelementclass = '',checkedstatus = '',dis = '', selectedClass = '', dropselection = '', otherdefaultelementclass = '';
					if (row[0].qState === 'S') { 
						checkedstatus = ' checked'; 
						countselected += 1;
						selectedClass = ' selected';
						dropselection = ' selected';
					}
					//if only one, but somewhere already selected... deselect rest. And if not variable
					if (layout.props.selectOnlyOne && !layout.props.dimensionIsVariable && countselected > 1){
						if (debug) console.log('Select only one enabled, reducing selections.');
						checkedstatus = ''; selectedClass = ''; dropselection = '';
						if (layout.props.visualizationType=='dropdown'){
						  //self.backendApi.selectValues( 0, [ row[0].qElemNumber ], false );
						  selectValueInQlik(self,row[0].qElemNumber,layout,app,false);
						} else {
						  //self.backendApi.selectValues( 0, [ row[0].qElemNumber ], false );
						  selectValueInQlik(self,row[0].qElemNumber,layout,app,false);
						}
						countselected -= 1; //reduce one because deselected
					}

					//mark defaultvalue
					if (layout.props.allwaysOneSelectedDefault != '' && row[0].qText == layout.props.allwaysOneSelectedDefault) {
						defaultelementclass = " defaultelement";
					}
					//mark other default values
					if (otherDefaultValues){
						if (otherDefaultValues.indexOf(row[0].qText) > -1){
							otherdefaultelementclass = " otherdefelem";
						}
					}
					
					//if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist' || layout.props.visualizationType=='checkbox' || layout.props.visualizationType=='btn' || layout.props.visualizationType=='radio'){
					if (layout.props.visualizationType!='dropdown'){
						var colorclasses = '';
						var elementstyle = ' style="';
						//color selections
						if (row[0].qState === 'S'){
							//set special color if set
							if (layout.props.color_stateS_bg && layout.props.color_stateS_bg != ''){
								colorclasses += ' disableBGimage';
								elementstyle += 'background-color:'+layout.props.color_stateS_bg+';';
							}
							//font color
							if (layout.props.color_stateS_fo && layout.props.color_stateS_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateS_fo+';';
							}
						} else if (row[0].qState === 'O'){
							if (layout.props.color_stateO_bg && layout.props.color_stateO_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateO_bg+';';
							}
							if (layout.props.color_stateO_fo && layout.props.color_stateO_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateO_fo+';';
							}
						} else if (row[0].qState === 'X'){
							if (layout.props.color_stateX_bg && layout.props.color_stateX_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateX_bg+';';
							}
							if (layout.props.color_stateX_fo && layout.props.color_stateX_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateX_fo+';';
							}
						} else if (row[0].qState === 'A'){
							if (layout.props.color_stateA_bg && layout.props.color_stateA_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateA_bg+';';
							}
							if (layout.props.color_stateA_fo && layout.props.color_stateA_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateA_fo+';';
							}
						}
						elementstyle += bordercolorstyle+elementStyleCSS;
						elementstyle += '"';
						//list
						if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
							html += '<li class="data '+selectedClass+defaultelementclass+otherdefaultelementclass+colorclasses+' state' + row[0].qState + ''+elementExtraClass+'" dval="' + row[0].qElemNumber + '"'+elementstyle+'' +elementExtraAttribute+ '>' + row[0].qText;
							html += '</li>';
						//checkbox
						} else if (layout.props.visualizationType=='checkbox'){
							html += '<label'+elementstyle+''+elementExtraClass+'>'
							html += '<input type="checkbox" class="data state' + row[0].qState +defaultelementclass+otherdefaultelementclass+selectedClass+colorclasses+ '" dval="' + row[0].qElemNumber + '"' + dis + checkedstatus +' ' +elementExtraAttribute+ '/> ' + row[0].qText; //
							html += '</label>';
						//button
						} else if (layout.props.visualizationType=='btn'){
							html += '<button'+elementstyle+''+elementExtraClass+''
							html += ' class="sfsbtn state' + row[0].qState +defaultelementclass+selectedClass+colorclasses+ '" dval="' + row[0].qElemNumber + '"' + dis + ' ' +elementExtraAttribute+ '> ' + row[0].qText; //
							html += '</button> ';
						//radio
						} else if (layout.props.visualizationType=='radio'){
							html += '<label'+elementstyle+''+elementExtraClass+'>'
							html += '<input type="radio" name="sfs'+layout.qInfo.qId+'" class="state' + row[0].qState +defaultelementclass+selectedClass+colorclasses+ '" dval="' + row[0].qElemNumber + '"' + dis + checkedstatus +' ' +elementExtraAttribute+ '/> ' + row[0].qText; //
							html += '</label>';
						}
					} else if (layout.props.visualizationType=='dropdown'){
						html += '<option class="state' + row[0].qState +defaultelementclass+selectedClass+ '" value="' + row[0].qElemNumber + '"' + dis + dropselection + ' > ' + row[0].qText;
						html += '</option>';
					}
				});
				if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
					html += '</ul>';
				}else if (layout.props.visualizationType=='dropdown'){
					html += '</select>';
				}else if (layout.props.visualizationType=='checkbox' || layout.props.visualizationType=='btn' || layout.props.visualizationType=='radio'){
					html += '</div>';
				}
				html += '</div>';
				if(labelAdded) html += '</label>';
				if (layout.props.helptext){
					html += '<div class="sfs_helptxt">'+ layout.props.helptext + '</div>';
				}
				if(paddingDivAdded) html += '</div>';
				var showContextMenu = 0;
				if (layout.props.rightclikcmenu && !layout.props.dimensionIsVariable && (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist' || layout.props.visualizationType=='checkbox')){
					showContextMenu = 1;
				}
				if (showContextMenu){
					html += '<ul class="sfsrmenu sfsrmenu'+layout.qInfo.qId+'">';
					if(layout.props.rightclikcmenu_selall) html += '<li act="selectall">Select all</li>';
					if(layout.props.rightclikcmenu_clear) html += '<li act="clear">Clear selections</li>';
					if(layout.props.rightclikcmenu_reverse) html += '<li act="reverse">Reverse selection</li>';
					if(layout.props.rightclikcmenu_possible) html += '<li act="possible">Select possible</li>';
					if(layout.props.rightclikcmenu_random) html += '<li act="random">Select randomnly</li>';
					if(layout.props.rightclikcmenu_defaults) html += '<li act="defaults">Select defaults</li>';
					html += '</ul>';
				}


				$element.html( html );
				//context menu actions
				if (showContextMenu){
					var sfsrmenu = $element.find('.sfsrmenu'+layout.qInfo.qId);
					$element.on("contextmenu", function (event) {
						event.preventDefault();
						sfsrmenu.finish().toggle(100).
						css({top: event.pageY + "px", left: event.pageX + "px"});
						$(document).on("mousedown", document, hidermenu);
					});
					function hidermenu(e){ //hide menu
						if (!$(e.target).parents(".sfsrmenu"+layout.qInfo.qId).length > 0) {
							//e.preventDefault();
							if (debug) console.log('menuhide');
							$(".sfsrmenu").hide(100);
							$(document).unbind('mousedown',hidermenu);
						}
					}
					sfsrmenu.find('li').click(function(){
						var action = $(this).attr('act');
						if (debug) console.log(action);
						sfsrmenu.hide(100);
						var valuesToSelect = [];
						if (action=='selectall'){
							if (debug) console.log('select all');
							$element.find('.data').each(function(){
								valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
							});
							
						} else 
						if (action=='clear'){
							if (debug) console.log('clear selections');
							//selectValuesInQlik(self, [] ,layout,app,false);
						} else 
						if (action=='reverse'){
							$element.find('.data').each(function(){
								if (!$(this).hasClass('selected')){
									valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
								}
							});
						} else 
						if (action=='possible'){
							$element.find('.data').each(function(){
								if ($(this).hasClass('stateO')){
									valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
								}
							});
						} else 
						if (action=='random'){
							$element.find('.data').each(function(){
								if (Math.random()>=0.5){
									valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
								}
							});
						} else 
						if (action=='defaults'){
							$element.find('.data').each(function(){
								if ($(this).hasClass('defaultelement') || $(this).hasClass('otherdefelem')) {
									valuesToSelect.push( parseInt($(this).attr( "dval" ),10) );
								}
							});
						}

						selectValuesInQlik(self, valuesToSelect ,layout,app,false);
					});
				}

				
				//list action
				if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
					/*var isMouseDown = false;
					//for mousedown select track mousedown
					$element.mousedown(function() {
        				isMouseDown = true;
					})
					.mouseup(function() {
						isMouseDown = false;
					});*/
					$element.find( '.checkboxgroup li' ).on( 'qv-activate', function (ev) { //mouseenter
						/*if(isMouseDown == false && ev.type=='mouseenter'){
							return;
						}*/
						var klikkauskohde = $(this);
						var kohteenValueID = parseInt(klikkauskohde.attr( "dval" ),10);
						if (debug) console.log('qv active on list change');
						//var value = parseInt( klikkauskohde.attr( "dval" ), 10 );

						if (!$(this).hasClass('selected')){
							if (debug) console.log('is selected');
							if (layout.props.selectOnlyOne){
							  if (debug) console.log('removing selections');
							  $element.find( '.selected' ).each(function(){
								var value = parseInt( $(this).attr( "dval" ), 10 );
								if (value != kohteenValueID){
								  selectValueInQlik(self,value,layout,app,true);
								  $(this).removeClass('selected');
								}
							  });
							}
							selectValueInQlik(self,kohteenValueID,layout,app,true);
							this.classList.toggle("selected");
						//deselect
						} else {
							if (debug) console.log('is not selected');
							klikkauskohde.removeClass('selected');
							selectValueInQlik(self,kohteenValueID,layout,app,true);
							var selectedCount = 0;
							$element.find( '.selected' ).each(function(){
							  selectedCount += 1;
							});
							checkDefaultValueSelection($element,selectedCount,layout,self,app);
						}
					} );
					/*$element.find( 'li' ).on( 'mouseenter', function () {
						if(isMouseDown){
							$(this).trigger('qv-activate');
						}
					});*/
					
				} else
				//dropdown change  layout.props.visualizationType=='radio'
				if (layout.props.visualizationType=='dropdown'){
					$element.find( '.dropdownsel' ).on('change',function(){
						if (debug) console.log('select change action');
						var klikkauskohde = $(this).find(":selected");
						var kohteenValueID = parseInt(klikkauskohde.val(),10);
						$element.find( '.selected' ).each(function(){
								var value = parseInt( $(this).val(), 10 );
								if (value != kohteenValueID){
								  selectValueInQlik(self,value,layout,app,true);
								  $(this).removeClass('selected');
								}
						});
						klikkauskohde.addClass('selected').prop('selected',true);
						selectValueInQlik(self,kohteenValueID,layout,app,true);
					});
				} else
				//attach click event to checkbox
				if (layout.props.visualizationType=='checkbox'){
				  $element.find( 'input' ).on( 'click', function () {
				  //self.backendApi.clearSelections();
					  if (debug) console.log('checkbox clicked action');
					  var klikkauskohde = $(this);
					  if ( $(this).attr( "dval" ) ) {
						  var kohteenValueID = parseInt(klikkauskohde.attr( "dval" ),10);
						  //when checking
						  if ($(this).is(':checked')){
							//if only one, clear others.
							if (layout.props.selectOnlyOne){
								$element.find( 'input:checked' ).each(function(){
									var value = parseInt( $(this).attr( "dval" ), 10 );
									if (value != kohteenValueID){
									  selectValueInQlik(self,value,layout,app,true);
									  $(this).prop('checked',false).removeClass('selected');
									}
								});
								//or is needed?
								klikkauskohde.prop('checked',true).addClass('selected');
							}
							selectValueInQlik(self,kohteenValueID,layout,app,true);
						  //remove check from box
						  } else {
							  //deselect
							  if (debug) console.log('deseelct');
							  //var value = parseInt( $(this).attr( "dval" ), 10 );
							  klikkauskohde.prop('checked',false).removeClass('selected');
							  if (debug) console.log(klikkauskohde.attr("dval"));
							  selectValueInQlik(self,kohteenValueID,layout,app,true);

							  var selectedCount = 0;
							  $element.find( 'input:checked' ).each(function(){
								  selectedCount += 1;
							  });
							  //default selection if needed
							  checkDefaultValueSelection($element,selectedCount,layout,self,app);
						  }
					  }
				  } );
				} else
				//Button action
				if (layout.props.visualizationType=='btn'){
					$element.find( 'button' ).on( 'click', function () {
						if (debug) console.log('Button clicked action');
						var klikkauskohde = $(this);
						if ( $(this).attr( "dval" ) ) {
							var kohteenValueID = parseInt(klikkauskohde.attr( "dval" ),10);
							var value = parseInt( klikkauskohde.attr( "dval" ), 10 );
							selectValueInQlik(self,value,layout,app,true);
						}
					} );
				//radio action
				} else if (layout.props.visualizationType=='radio'){
					$element.find( 'input' ).on('click',function(){
						if (debug) console.log('radio change action');
						var klikkauskohde = $(this);
						var kohteenValueID = parseInt(klikkauskohde.attr( "dval" ),10);
						$element.find( '.selected' ).each(function(){
								var value = parseInt( $(this).attr( "dval" ), 10 );
								if (value != kohteenValueID){
								  selectValueInQlik(self,value,layout,app,true);
								  $(this).removeClass('selected');
								}
						});
						klikkauskohde.addClass('selected').prop('selected',true);
						selectValueInQlik(self,kohteenValueID,layout,app,true);
					});

				} //if
				//as default:
				checkDefaultValueSelection($element,countselected,layout,self,app);
			}
			return qlik.Promise.resolve();
		}
	};
} );
