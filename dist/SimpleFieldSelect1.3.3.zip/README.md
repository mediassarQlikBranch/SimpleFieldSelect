Qlik Sense extension for field and variable selections.
