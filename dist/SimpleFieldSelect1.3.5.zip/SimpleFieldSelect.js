define( ["qlik", "jquery", "text!./SimpleFieldStyle.css","text!./datepicker.css","./jquery-ui.min"], function ( qlik, $, cssContent, cssDatepick ) {
	'use strict';
	$( "<style>" ).html( cssContent ).appendTo( "head" );
	$( "<style>" ).html( cssDatepick ).appendTo( "head" );
	var debug = false;
	
	//If nothing selected but should be
	function checkDefaultValueSelection($element,countselected,layout,self,app){
	  if(debug) console.log('checkin default selection, selected: '+countselected);
	  if (countselected==0 && layout.props.allwaysOneSelectedDefault != ''){
		var defaulttoselect = $element.find( '.defaultelement' );
		//check if element is found
		if (defaulttoselect.length<1) {
			if(debug) console.log('Default value was not found');
			return;
		}
		if (layout.props.visualizationType=='dropdown'){
		  //self.backendApi.selectValues( 0, [ parseInt(defaulttoselect.val(),10) ], false );
		  selectValueInQlik(self, parseInt(defaulttoselect.val(),10) ,layout,app,false);
		} else {
		  //self.backendApi.selectValues( 0, [ parseInt(defaulttoselect.attr( "data-value" ),10) ], false );
		  selectValueInQlik(self, parseInt(defaulttoselect.attr( "data-value" ),10) ,layout,app,false);
		}
	  }
	}
	function selectValueInQlik(self,value,layout,app,selectvalueMethod){ //selectvalueMethod true or false
		if(debug) console.log('set value to index '+value);
		//Variable
		if (layout.props.dimensionIsVariable){
			var valueTxt = layout.props.variableOptionsForValuesArray[ value ];
			//if value is not defined, forexample nothing is selected for variable.
			if (typeof valueTxt == 'undefined' ){
				valueTxt = '';
			}
			if(debug) console.log(' means '+valueTxt+' to variable ' +layout.props.variableName);
			//set variable
			app.variable.setContent(layout.props.variableName, valueTxt);
			//set key value too if defined
			if (layout.props.variableOptionsForKeysArray != [] && layout.props.variableNameForKey && layout.props.variableOptionsForKeysArray[ value ]){
				var keyTxt = layout.props.variableOptionsForKeysArray[ value ];
				if(debug) console.log(' key value '+keyTxt+' to variable ' +layout.props.variableNameForKey);
				app.variable.setContent(layout.props.variableNameForKey, keyTxt);
			}
		//set field
		} else {
			self.backendApi.selectValues( 0, [value], selectvalueMethod );
		}
	}
	//calc variable name IF this is variable selection
	function findVariableName(listobject,props){
		if(debug){ console.log(listobject); console.log(props); }
		props.variableName = props.hideFromSelectionRealField;
		if (props.variableName == '' || !props.variableName){
			//listobject.variableName = listobject.qDimensionInfo.qGroupFieldDefs[0]; //try this one if not defined.
			props.variableName = listobject.qDef.qFieldDefs[0];
			if(debug){ console.log(props.variableName); }
			props.variableName = props.variableName.replace("=",'');
		}
	}
	return {
		initialProperties: {
			qListObjectDef: {
				qShowAlternatives: true,
				//qFrequencyMode: "V",
				qInitialDataFetch: [{
					qWidth: 2,
					qHeight: 1000
				}],
				qSortByState: 0,
			},
			variableValue: {},
			maxLimitvariableValue: {},
			props: {
				dimensionIsVariable: false
			}
		},
		
		definition: {
			
			type: "items",
			component: "accordion",
			items: {
				dimensions: {
					type: "items",
					label: "Dimensions",
					ref: "qListObjectDef",
					min: 1,
					max: 1,
					items: {
						label: {
							type: "string",
							ref: "qListObjectDef.qDef.qFieldLabels.0",
							label: "Label",
							show: false
						},
						field: {
							type: "string",
							expression: "always",
							expressionType: "dimension",
							ref: "qListObjectDef.qDef.qFieldDefs.0",
							label: "Field or variable name",
							show: function ( data ) {
								return data.qListObjectDef && !data.qListObjectDef.qLibraryId;
							},
							change: function(data) {
								if(debug) console.log('variable name is '+data.qListObjectDef.variableName);
								if (data.props.dimensionIsVariable){
									if(debug) console.log(data);
									data.variableValue = data.variableValue || {};
									data.variableValue.qStringExpression = '=' + data.props.variableName;
									if(debug) console.log('variable expression: '+data.variableValue.qStringExpression);
								}
                            }
						},
						dimensionIsVariable: {
						  ref: "props.dimensionIsVariable",
						  type: "boolean",
						  label: "Target field is variable",
						  defaultValue: false,
						  change: function(data) {
							if (data.props.dimensionIsVariable){
								if(debug) console.log(data);
								findVariableName(data.qListObjectDef,data.props);
								//data.props.variableName = data.props.variableName.replace("=",''); //remove mark if exists.
								data.variableValue = data.variableValue || {};
								data.variableValue.qStringExpression = '=' + data.props.variableName; //.qDef.qFieldDefs[0];
								if(debug) console.log('variable expression is =' + data.props.variableName);
							}
                          }
                        },
						qSortByState: {
							type: "numeric", component: "dropdown",
							label: "Sort by state",
							ref: "qListObjectDef.qDef.qSortCriterias.0.qSortByState",
							options: [
								{value: 1,label: "Ascending"},
								{value: 0,label: "No"},
								{value: -1,label: "Descending"}
							],
							defaultValue: 0,
							show: function ( data ) {
								return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
							}
						},
						qSortByNumeric: {
							type: "numeric", component: "dropdown",
							label: "Sort by numeric value",
							ref: "qListObjectDef.qDef.qSortCriterias.0.qSortByNumeric",
							options: [
								{value: 1,label: "Ascending"},
								{value: 0,label: "No"},
								{value: -1,label: "Descending"}
							],
							defaultValue: 0,
							show: function ( data ) {
								return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
							}
						},
						qSortByLoadOrder: {
							type: "numeric", component: "dropdown",
							label: "Sort by load order",
							ref: "qListObjectDef.qDef.qSortCriterias.0.qSortByLoadOrder",
							options: [
								{value: 1,label: "Ascending"},
								{value: 0,label: "No"},
								{value: -1,label: "Descending"}
							],
							defaultValue: 0,
							show: function ( data ) {
								return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
							}
						},
						qSortByAscii: {
							type: "numeric", component: "dropdown",
							label: "Sort by text",
							ref: "qListObjectDef.qDef.qSortCriterias.0.qSortByAscii",
							options: [
								{value: 1,label: "Ascending"},
								{value: 0,label: "No"},
								{value: -1,label: "Descending"}
							],
							defaultValue: 0,
							show: function ( data ) {
								return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
							}
						},
						qSortByFrequency: {
							type: "numeric", component: "dropdown",
							label: "Sort by frequency",
							ref: "qListObjectDef.qDef.qSortCriterias.0.qSortByFrequency",
							options: [
								{value: 1,label: "Ascending"},
								{value: 0,label: "No"},
								{value: -1,label: "Descending"}
							],
							defaultValue: 0,
							show: function ( data ) {
								return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
							}
						}
					}
				},
				//sorting: { uses: "sorting" },
				settings: {
					uses: "settings",
					items: {
                        
						variableOptions:{
							type: "items",
							label: "Variable options",
							show: function ( data ) {
								return data.qListObjectDef && data.props && data.props.dimensionIsVariable;
							},
							items:{
								variableIsDate: {
									ref: "props.variableIsDate",
									type: "boolean",
									label: "Variable is a date selector?",
									show: function ( data ) {
										return data.qListObjectDef && data.props && data.props.dimensionIsVariable;
									}
								},
								maxname: {
									ref: "props.maxLimitvariable",
									label: "Limit date selection to max from variable",
									type: "string",
									show: function ( data ) {
										return data.qListObjectDef && data.props && data.props.variableIsDate && data.props.dimensionIsVariable;
									},
									expression:"optional"
								},
								dateformatSelect: {
									ref: "props.dateformat",
									label: "Date format to use, match with document, use javascript format",
									type: "string",
									defaultValue: "d.m.yy",
									show: function ( data ) {
										return data.qListObjectDef && data.props && data.props.variableIsDate && data.props.dimensionIsVariable;
									},
									expression:"optional"
								},
								variableOptionsForValues: {
									ref: "props.variableOptionsForValues",
									label: "Options for values, separate by ;",
									type: "string",
									defaultValue: "",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !data.props.variableIsDate && data.props.dimensionIsVariable;
									},
									expression:"optional"
								},
								aboutSecondVariable:{
									component: "text",
									label: "You can set another variable to follow the main variables selections. You can use this feature like a key for the first variable",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !data.props.variableIsDate && data.props.dimensionIsVariable;
									}
								},
								variableNameForKey: {
									ref: "props.variableNameForKey",
									label: "(Opt) Variable name for second variable",
									type: "string",
									defaultValue: "",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !data.props.variableIsDate && data.props.dimensionIsVariable;
									}
								},
								aboutSecondVariableOptions:{
									component: "text",
									label: "Define as many options as there are options for the main variable",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !data.props.variableIsDate && data.props.dimensionIsVariable && data.props.variableNameForKey;
									}
								},
								variableOptionsForKeys: {
									ref: "props.variableOptionsForKeys",
									label: "Define key values, separate by ;",
									type: "string",
									defaultValue: "",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !data.props.variableIsDate && data.props.dimensionIsVariable && data.props.variableNameForKey;
									},
									expression:"optional"
								}
							}
						},
						Selections: {
							type: "items",
							label: "Selections",
							show: function ( data ) {
										return data.qListObjectDef && data.props && !(data.props.variableIsDate && data.props.dimensionIsVariable);
							},
							items: {
								selectDefault: {
									type: "string",
									label: "Select this one as default",
									ref: "props.allwaysOneSelectedDefault",
									defaultValue: "",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !(data.props.variableIsDate && data.props.dimensionIsVariable);
									},
									expression:"optional"
								},
								SelectOnyOneOption: {
								  ref: "props.selectOnlyOne",
								  type: "boolean",
								  label: "Select only one?",
								  defaultValue: false,
								  show: function ( data ) {
										return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable) && data.props.visualizationType!='dropdown';
								  }
								},
								hidePassiveItems: {
								  ref: "props.hidePassiveItems",
								  type: "boolean",
								  label: "Hide items which cannot be selected",
								  defaultValue: false,
								  show: function ( data ) {
										return data.qListObjectDef && data.props && !(data.props.dimensionIsVariable);
								  }
								}
							}
						},
						Hiding: {
							type: "items",
							label: "Hiding",
							show: function ( data ) {
								return data.qListObjectDef && data.props && !data.props.dimensionIsVariable;
							},
							items: {
								HideFromSelectionsBar: {
								  ref: "props.hideFromSelectionsBar",
								  type: "boolean",
								  label: "Hide from selections bar",
								  defaultValue: false,
								  show: true

								},
								HideFromSelectionsFieldOptional: {
								  ref: "props.hideFromSelectionRealField",
								  type: "string",
								  label: "(Opt) Name of the field without special marks (if field has [ mark)",
								  defaultValue: "",
								  show: function ( data ) {
										return data.qListObjectDef && data.props && (data.props.hideFromSelectionsBar);
								  }

								},
							}
						},
						Visualization: {
							type: "items",
							label: "Visualization",
							items: {
								VisualizationType: {
									type: "string",
									component: "dropdown",
									label: "Visualization",
									ref: "props.visualizationType",
									options: [{
										value: "checkbox",label: "Checkbox"}, {
										value: "vlist",label: "Vertical QlikSense list"}, {
										value: "hlist",label: "Horizontal QlikSense list"}, {
										value: "dropdown",label: "Dropdown"}, {
										value: "btn",label: "Standard HTML button"}],
									defaultValue: "hlist",
									show: function ( data ) {
										return data.qListObjectDef && data.props && !(data.props.variableIsDate && data.props.dimensionIsVariable);
									}
								},
								DropdownValueForNoSelect: {
									type: "string",
									label: "No selection -text in drop down menu",
									ref: "props.dropdownValueForNoSelect",
									defaultValue: '',
									expression:"optional",
									show: function ( data ) {
										return data.qListObjectDef && data.props && data.props.visualizationType=='dropdown';
									}
								},
								fontsize: {
									type: "string",
									component: "dropdown",
									label: "Font size",
									ref: "props.fontsizeChange",
									options: [
										{value: "75",label: "75%"},
										{value: "100",label: "100%"},
										{value: "125",label: "125%"}],
									defaultValue: "100"
								},
								contentpadding: {
									type: "string",
									component: "dropdown",
									label: "Padding for the content",
									ref: "props.contentpadding",
									options: [
										{value: "-",label: "default"},
										{value: "2",label: "2px"},
										{value: "4",label: "4px"},
										{value: "6",label: "6px"},
										{value: "8",label: "8px"},
										{value: "10",label: "10px"},
										{value: "12",label: "12px"},
										{value: "16",label: "16px"}],
									defaultValue: "-"
								},
								leftpadding: {
									type: "string",
									component: "dropdown",
									label: "Padding for the qlik default left margin",
									ref: "props.leftpadding",
									options: [
										{value: "-",label: "default"},
										{value: "0",label: "0px"},
										{value: "2",label: "2px"},
										{value: "4",label: "4px"},
										{value: "6",label: "6px"},
										{value: "8",label: "8px"},
										{value: "10",label: "10px"},
										{value: "12",label: "12px"},
										{value: "16",label: "16px"}],
									defaultValue: "-"
								},
								showHeader: {
								  ref: "props.showHeader",
								  type: "boolean",
								  label: "Show default header?",
								  defaultValue: true
								},
								headerheightsize: {
									type: "string",
									component: "dropdown",
									label: "Header height in pixels",
									ref: "props.headerSize",
									options: [
										{value: "-",label: "default"},
										{value: "2",label: "2px"},
										{value: "6",label: "6px"},
										{value: "10",label: "10px"},
										{value: "14",label: "14px"},
										{value: "18",label: "18px"},
										{value: "22",label: "22px"},
										{value: "26",label: "26px"},
										{value: "30",label: "30px"},
										{value: "36",label: "36px"},
										{value: "42",label: "42px"},
										{value: "50",label: "50px"}],
									defaultValue: "-",
									show: function ( data ) {
										return data.qListObjectDef && data.props &&  data.props.showHeader;
									}
								},
								headerbottompadding: {
									type: "string",
									component: "dropdown",
									label: "Header bottom padding",
									ref: "props.headerBpadding",
									options: [
										{value: "-",label: "default"},
										{value: "2",label: "2px"},
										{value: "6",label: "6px"},
										{value: "8",label: "8px"},
										{value: "10",label: "10px"},
										{value: "14",label: "14px"},
										{value: "18",label: "18px"},
										{value: "22",label: "22px"},
										{value: "26",label: "26px"}],
									defaultValue: "-",
									show: function ( data ) {
										return data.qListObjectDef && data.props &&  data.props.showHeader;
									}
								},
								transparentBackground: {
								  ref: "props.transparentBackground",
								  type: "boolean",
								  label: "Transparent background?",
								  defaultValue: false
								},
								noBorders: {
								  ref: "props.noBorders",
								  type: "boolean",
								  label: "No borders? (disabling requires reload)",
								  defaultValue: false
								},
								mobileRemoveZoom: {
								  ref: "props.mobileRemoveZoom",
								  type: "boolean",
								  label: "Disable mobile zoom effect? (less clicking)",
								  defaultValue: true
								},
								mobileContainerHeight: {
								  ref: "props.mobileCustomHeightCSS",
								  type: "string",
								  label: "Custom height css parameter for mobile (65px or 50%)",
								  defaultValue: ''
								},
								hlistRoundedcorners: {
								  ref: "props.hlistRoundedcorners",
								  type: "boolean",
								  label: "Rounded corners in horizontal list?",
								  defaultValue: true,
								  show: function ( data ) {
									return data.qListObjectDef && data.props &&  data.props.visualizationType=='hlist';
								  }
								},
								hlistMarginBetween: {
									type: "string",
									component: "dropdown",
									label: "Margin between horizontal list elements",
									ref: "props.hlistMarginBetween",
									options: [
										{value: "0",label: "0px"},
										{value: "1",label: "1px"},
										{value: "2",label: "2px"},
										{value: "3",label: "3px"},
										{value: "4",label: "4px"},
										{value: "5",label: "5px"},
										{value: "6",label: "6px"},
										{value: "7",label: "7px"},
										{value: "8",label: "8px"}],
									defaultValue: "1",
									show: function ( data ) {
										return data.qListObjectDef && data.props && data.props.visualizationType=='hlist';
									}
								},
								hlistShowAsTable: {
								  ref: "props.hlistShowAsTable",
								  type: "boolean",
								  label: "Show as \"table \"?",
								  defaultValue: false,
								  show: function ( data ) {
									return data.qListObjectDef && data.props &&  data.props.visualizationType=='hlist';
								  }
								},
								customFontCSS: {
								  ref: "props.customFontCSS",
								  type: "string",
								  label: "Custom font css string",
								  defaultValue: ''
								},
								customElementAttribute: {
								  ref: "props.customElementAttribute",
								  type: "string",
								  label: "Custom HTML attribute for every element",
								  defaultValue: ''
								},
								customElementClass: {
								  ref: "props.customElementClass",
								  type: "string",
								  label: "Custom HTML class for every element",
								  defaultValue: ''
								},
								customStyleCSS: {
								  ref: "props.customStyleCSS",
								  type: "string",
								  label: "Custom CSS style for every element",
								  defaultValue: ''
								}
							}
						},
						Texts: {
							type: "items",
							label: "Texts",
							items: {
								inlinelabel: {
									type: "string",
									label: "Label text",
									ref: "props.inlinelabeltext",
									defaultValue: '',
									expression:"optional"
								},
								setlabelInline: {
									ref: "props.inlinelabelSetinline",
								  	type: "boolean",
								  	label: "Set label inline?",
								  	defaultValue: false
								},
								helptext: {
									type: "string",
									label: "Help text",
									ref: "props.helptext",
									defaultValue: '',
									expression:"optional"
								},
								hovertitle: {
									type: "string",
									label: "Text on mouse hover",
									ref: "props.hovertitletext",
									defaultValue: '',
									expression:"optional"
								}
							}
						},
						Colors: {
							type: "items",
							label: "Colors",
							items: {
								aboutcolors:{
									component: "text",
									label: "If field is empty, \"default\" value is used. Use CSS color codes, like #fed, blue, #123456"
								},
								color_stateS_bg: {
									type: "string",
									label: "Selected background",
									ref: "props.color_stateS_bg",
									defaultValue: '',
									expression:"optional"
								},
								color_stateN_bg: {
									type: "string",
									label: "Possible selection background",
									ref: "props.color_stateO_bg",
									defaultValue: '',
									expression:"optional"
								},
								color_stateA_bg: {
									type: "string",
									label: "Alternative selection background",
									ref: "props.color_stateA_bg",
									defaultValue: '',
									expression:"optional"
								},
								color_stateX_bg: {
									type: "string",
									label: "Excluded selection background",
									ref: "props.color_stateX_bg",
									defaultValue: '',
									expression:"optional"
								},
								fontcolors:{
									component: "text",
									label: "Font colors"
								},
								color_stateS_fo: {
									type: "string",
									label: "Selected text color",
									ref: "props.color_stateS_fo",
									defaultValue: '',
									expression:"optional"
								},
								color_stateN_fo: {
									type: "string",
									label: "Possible selection text color",
									ref: "props.color_stateO_fo",
									defaultValue: '',
									expression:"optional"
								},
								color_stateA_fo: {
									type: "string",
									label: "Alternative selection text color",
									ref: "props.color_stateA_fo",
									defaultValue: '',
									expression:"optional"
								},
								color_stateX_fo: {
									type: "string",
									label: "Excluded selection text color",
									ref: "props.color_stateX_fo",
									defaultValue: '',
									expression:"optional"
								},
								othercolors:{
									component: "text",
									label: "Other colors"
								},
								color_border: {
									type: "string",
									label: "Border color",
									ref: "props.color_border",
									defaultValue: '',
									expression:"optional"
								}
							}
						}
					}
				},
				abouttxt:{
					label: "About",
					type: "items",
					items: {
						aboutt:{
							component: "text",
							label: "Developed by Matti Punkeri / Mediassar Oy"
						}
					}
				}
			}
		},
		support : {
			snapshot: false,
			export: false,
			exportData : false
		},
		paint: function ( $element,layout ) {
			if (debug){ console.log('start painting');	console.log(layout); }
			var self = this, html = "";
			var app = qlik.currApp();
			//change header size
			var headerelement = $element.parent().parent().prev();
			if (layout.props && layout.props.showHeader){
				headerelement.show();
				if (layout.props.headerSize && layout.props.headerSize != '-'){
					headerelement.css('height',layout.props.headerSize+'px');
				}
				if (layout.props.headerBpadding && layout.props.headerBpadding != '-'){
					headerelement.css('padding-bottom',layout.props.headerBpadding+'px');
				}
			} else {
				headerelement.hide();
			}
			//borders and bg
			var articleInnerElement = headerelement.parent();
			var articleElement = articleInnerElement.parent();
			if (layout.props.transparentBackground){
				articleElement.css('background-color','transparent');
				articleInnerElement.css('background-color','transparent');
			} else {
				articleElement.css('background-color','');
				articleInnerElement.css('background-color','');
			}
			if (layout.props.noBorders){
				articleElement.css('border-width','0');
			}
			//left padding in one qlik theme
			if(layout.props.leftpadding && layout.props.leftpadding != '-'){
				articleInnerElement.css('padding-left',layout.props.leftpadding+'px');
			}
			//padding
			var paddingDivAdded = 0;
			if(layout.props.contentpadding && layout.props.contentpadding != '-'){
				html += '<div style="padding:'+layout.props.contentpadding +'px">';
				paddingDivAdded = 1;
			}
			//extra label
			var labelAdded = 0;
			if(layout.props.inlinelabeltext){
				html += '<label class=inlinelabel><div class="inlinelabeldiv';
				if (layout.props.inlinelabelSetinline){
					html += ' inlinelabeldivInline';
				}
				html += '">'+layout.props.inlinelabeltext+'</div> ';
				labelAdded = 1;
			}
			//change for mobile
			if ($('.smallDevice').length >0){ //$(window).width()<600
				var parent = $element.closest('.qv-gridcell');
				//console.log(parent.html());
				if(layout.props.mobileRemoveZoom){
					parent.find('.transparent-overlay').remove(); //remove mobile zoom haveto
				}
				//set height, default is too high
				if(layout.props.mobileCustomHeightCSS && layout.props.mobileCustomHeightCSS != ''){
					parent.css('height',layout.props.mobileCustomHeightCSS);
				} else {
					parent.css('height','65px');
				}
			}
			
			//hide
			if (layout.props.hideFromSelectionsBar){
				var fieldToHide = layout.props.hideFromSelectionRealField;
				if (fieldToHide == '' || !fieldToHide){
					fieldToHide = layout.qListObject.qDimensionInfo.qGroupFieldDefs[0]; //try this one if not defined.
					if (fieldToHide.slice(0,1)==='='){ //if first letter =
						fieldToHide = fieldToHide.slice(1);
					}
					fieldToHide = fieldToHide.replace(/[\[\]']+/g,''); //reomve []
				}
				//add hide area if needed
				if ($(".hideselstyles").length>0){
					
				} else {
					$('.qv-selections-pager').append('<div style="display:none;" class=hideselstyles></div>');
				}
				if ($('#hid'+fieldToHide).length>0){
					//already hidden
				} else {
					$('.hideselstyles').append('<style id="hid'+fieldToHide+'">.qv-selections-pager li[data-csid="'+ fieldToHide +'"] {display:none;}</style>');
				}
			}
			//get variable value
			var varvalue = '';
			if (layout.props.dimensionIsVariable){
				varvalue = layout.variableValue;
				if (debug){ console.log('varvalue from '+layout.props.variableName+' is '); console.log(varvalue); }
			}
			var fontStyleTxt = '';
			if (layout.props.customFontCSS && layout.props.customFontCSS != ''){
				fontStyleTxt = ' font:'+layout.props.customFontCSS+';';
			}
			var elementStyleCSS = '';
			if (layout.props.customStyleCSS && layout.props.customStyleCSS != ''){
				elementStyleCSS = ' '+layout.props.customStyleCSS+';';
			}
			var elementExtraAttribute = '';
			if (layout.props.customElementAttribute && layout.props.customElementAttribute != ''){
				elementExtraAttribute = ' '+layout.props.customElementAttribute+' ';
			}
			var elementExtraClass = '';
			if (layout.props.customElementClass && layout.props.customElementClass != ''){
				elementExtraClass = ' '+layout.props.customElementClass+' ';
			}
			var fontsizechanges = '';
			if (layout.props.fontsizeChange && layout.props.fontsizeChange != ''){
				fontsizechanges = ' font-size:'+layout.props.fontsizeChange+'%;';
			}
			//if date select to variable
			if (layout.props.variableIsDate && layout.props.dimensionIsVariable){
				if (layout.props.variableName){
					if (debug){ console.log('alkuarvo ' + layout.props.variableName); console.log(app.variable.getContent(layout.props.variableName)); }
					
					html += '<input type=text title="Click to select date" class="pickdate'+elementExtraClass+'" value="'+varvalue+'" style="width:6em; max-width:80%;'+fontsizechanges+fontStyleTxt+elementStyleCSS+'"' +elementExtraAttribute+ '/>';
					if(labelAdded) html += '</label>';
					if (layout.props.helptext){
						html += '<div class="sfs_helptxt">'+ layout.props.helptext + '</div>';
					}
					if(paddingDivAdded) html += '</div>';
					$element.html( html );
					
					var datepickElement = $element.find( '.pickdate' );
					datepickElement.datepicker({
						dateFormat: layout.props.dateformat,
						changeMonth: true,
						changeYear: true,
						showOn: "both",
						firstDay:1,
						constrainInput: true
					});
					 //dates limited?
					//if (debug) {console.log(layout.props.maxLimitvariable);}
					if (layout.props.maxLimitvariable && layout.props.maxLimitvariable && layout.props.maxLimitvariable != '-'){
						if (debug){ console.log('Limiting days to '); console.log(layout.props.maxLimitvariable); }
						var parsedDate = $.datepicker.parseDate(layout.props.dateformat, layout.props.maxLimitvariable);
						datepickElement.datepicker( "option", "maxDate", parsedDate );
					}
					$element.find( '.pickdate' ).on( 'change', function () {
						var newval = $(this).val();
						if(debug) console.log('NEW '+newval + ' to '+layout.props.variableName);
						app.variable.setContent(layout.props.variableName, newval);
					});
				}
			//not date select:
			} else {
			
			
				html += '<div class="checkboxgroup"';
				if (layout.props.hovertitletext && layout.props.hovertitletext != ''){
					html += ' title="'+layout.props.hovertitletext.replace(/\"/g,'&quot;')+'"'; //escape quotas!!
				}
				html += '>';
				/* //style usage would require this element selector
				html += '<style>';
				if (layout.props.color_border && layout.props.color_border != ''){
					html += '.qv-object-SimpleFieldSelect li.data, .qv-object-SimpleFieldSelect ul.horizontal li { border-color:'+layout.props.color_border+'; }';
					
				}
				html += '</style>';*/
				var countselected = 0;
				var stylechanges = ' style="'+fontsizechanges+fontStyleTxt;
				stylechanges += '"';
				if (layout.props.visualizationType=='vlist'){
					html += '<ul'+stylechanges+'>';
				}else if (layout.props.visualizationType=='hlist'){
					var roundcornerClass=' rcorners';
					if (layout.props.hlistRoundedcorners===false){
						roundcornerClass='';
					}
					var rmarginclass = ' rmargin1';
					if (layout.props.hlistMarginBetween >= 0){ //its defined
						rmarginclass = ' rmargin'+layout.props.hlistMarginBetween;
					}
					var displayastableClass = '';
					if (layout.props.hlistShowAsTable){
						displayastableClass = ' ulastable'
					}
					html += '<ul class="horizontal'+roundcornerClass+rmarginclass+displayastableClass+'" '+stylechanges+'>';
				} else if (layout.props.visualizationType=='checkbox'){
					html += '<div '+stylechanges+'>';
				} else if (layout.props.visualizationType=='dropdown'){
					html += '<select class="dropdownsel'+elementExtraClass+'" '+stylechanges+'' +elementExtraAttribute+ '>';
				} else if (layout.props.visualizationType=='btn'){
					html += '<div '+stylechanges+'>';
				} else {
					html += 'Select visualization type';
				}
				//border color style
				var bordercolorstyle = '';
				if (layout.props.color_border && layout.props.color_border != ''){
					bordercolorstyle = ' border-color:'+layout.props.color_border+';';
				}
				//print elements
				var optionsforselect = [];
				if (layout.props.dimensionIsVariable){
					//generate variable options from field
					if (debug) console.log('variable value '+varvalue);
					if (!layout.props.variableOptionsForValues){
						html += 'Set variable options or enable date selector';
					}
					var splitted = layout.props.variableOptionsForValues.split(";");
					var varindex = 0; //index is used to access variable
					layout.props.variableOptionsForValuesArray = [];
					layout.props.variableOptionsForKeysArray = [];
					splitted.forEach(function(opt){
						var qState = 'O';
						//if values match with current, mark selected
						if (varvalue == opt) {
							qState = 'S'; 
						} //build qlik style object for printing
						optionsforselect.push( [{qState:qState, qText:opt, qElemNumber:varindex}] );
						layout.props.variableOptionsForValuesArray.push(opt); //when setting variable, take value from here.
						varindex += 1;
					});
					if (debug){ console.log(layout.props.variableOptionsForValues); }
					//if separate Keys variable is defined:
					var varKeyindex = 0;
					if (layout.props.dimensionIsVariable && layout.props.variableOptionsForKeys != ''){
						splitted = layout.props.variableOptionsForKeys.split(";");
						splitted.forEach(function(opt){
							layout.props.variableOptionsForKeysArray.push(opt); //when setting variable, take value from here.
							varKeyindex += 1;
						});
						if (varindex != varKeyindex){
							console.log('variable values and key options do not match. Values: '+varindex + ' vs. keys: '+varKeyindex);
							layout.props.variableOptionsForKeysArray = []; //reset array
						}
					}
					
				//if not variable:
				} else {
					optionsforselect = layout.qListObject.qDataPages[0].qMatrix;
				}
				//dropdown default option
				if (layout.props.visualizationType=='dropdown' && layout.props.dropdownValueForNoSelect && layout.props.dropdownValueForNoSelect != ''){
					html += '<option class="state0" value=""> ' + layout.props.dropdownValueForNoSelect;
					html += '</option>';
				}
				
				//paint options
				optionsforselect.forEach( function ( row ) {
					if (layout.props.hidePassiveItems && !layout.props.dimensionIsVariable && row[0].qState === 'X'){ //if passive hiding enabled
						return; //exit current function
					}
					//var elementid = layout.qInfo.qId+''+row[0].qElemNumber;
					var defaultelementclass = '',checkedstatus = '',dis = '', selectedClass = '', dropselection = '';
					if (row[0].qState === 'S') { 
						checkedstatus = ' checked'; 
						countselected += 1;
						selectedClass = ' selected';
						dropselection = ' selected';
					}
					//if only one, but somewhere already selected... deselect rest. And if not variable
					if (layout.props.selectOnlyOne && !layout.props.dimensionIsVariable && countselected > 1){
						if (debug) console.log('Select only one enabled, reducing selections.');
						checkedstatus = ''; selectedClass = ''; dropselection = '';
						if (layout.props.visualizationType=='dropdown'){
						  self.backendApi.selectValues( 0, [ row[0].qElemNumber ], false );
						} else {
						  self.backendApi.selectValues( 0, [ row[0].qElemNumber ], false );
						}
						countselected -= 1; //reduce one because deselected
					}

					//mark defaultvalue
					if (layout.props.allwaysOneSelectedDefault != '' && row[0].qText == layout.props.allwaysOneSelectedDefault) {
						defaultelementclass = " defaultelement";
					}
					
					if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist' || layout.props.visualizationType=='checkbox' || layout.props.visualizationType=='btn'){
						var colorclasses = '';
						var elementstyle = ' style="';
						//color selections
						if (row[0].qState === 'S'){
							//set special color if set
							if (layout.props.color_stateS_bg && layout.props.color_stateS_bg != ''){
								colorclasses += ' disableBGimage';
								elementstyle += 'background-color:'+layout.props.color_stateS_bg+';';
							}
							//font color
							if (layout.props.color_stateS_fo && layout.props.color_stateS_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateS_fo+';';
							}
						} else if (row[0].qState === 'O'){
							if (layout.props.color_stateO_bg && layout.props.color_stateO_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateO_bg+';';
							}
							if (layout.props.color_stateO_fo && layout.props.color_stateO_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateO_fo+';';
							}
						} else if (row[0].qState === 'X'){
							if (layout.props.color_stateX_bg && layout.props.color_stateX_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateX_bg+';';
							}
							if (layout.props.color_stateX_fo && layout.props.color_stateX_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateX_fo+';';
							}
						} else if (row[0].qState === 'A'){
							if (layout.props.color_stateA_bg && layout.props.color_stateA_bg != ''){
								elementstyle += 'background-color:'+layout.props.color_stateA_bg+';';
							}
							if (layout.props.color_stateA_fo && layout.props.color_stateA_fo != ''){
								elementstyle += ' color:'+layout.props.color_stateA_fo+';';
							}
						}
						elementstyle += bordercolorstyle+elementStyleCSS;
						elementstyle += '"';
						//list
						if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
							html += '<li class="data '+selectedClass+defaultelementclass+colorclasses+' state' + row[0].qState + ''+elementExtraClass+'" data-value="' + row[0].qElemNumber + '"'+elementstyle+'' +elementExtraAttribute+ '>' + row[0].qText;
							html += '</li>';
						//checkbox
						} else if (layout.props.visualizationType=='checkbox'){
							html += '<label'+elementstyle+''+elementExtraClass+'>'
							html += '<input type="checkbox" class="state' + row[0].qState +defaultelementclass+selectedClass+colorclasses+ '" data-value="' + row[0].qElemNumber + '"' + dis + checkedstatus +' ' +elementExtraAttribute+ '/> ' + row[0].qText; //
							html += '</label>';
						//button
						} else if (layout.props.visualizationType=='btn'){
							html += '<button'+elementstyle+''+elementExtraClass+''
							html += ' class="sfsbtn state' + row[0].qState +defaultelementclass+selectedClass+colorclasses+ '" data-value="' + row[0].qElemNumber + '"' + dis + ' ' +elementExtraAttribute+ '> ' + row[0].qText; //
							html += '</button> ';
						}
					} else if (layout.props.visualizationType=='dropdown'){
						html += '<option class="state' + row[0].qState +defaultelementclass+selectedClass+ '" value="' + row[0].qElemNumber + '"' + dis + dropselection + ' > ' + row[0].qText;
						html += '</option>';
					}
				});
				if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
					html += '</ul>';
				}else if (layout.props.visualizationType=='dropdown'){
					html += '</select>';
				}else if (layout.props.visualizationType=='checkbox' || layout.props.visualizationType=='btn'){
					html += '</div>';
				}
				html += '</div>';
				if(labelAdded) html += '</label>';
				if (layout.props.helptext){
					html += '<div class="sfs_helptxt">'+ layout.props.helptext + '</div>';
				}
				if(paddingDivAdded) html += '</div>';
				$element.html( html );
				
				//list action
				if (layout.props.visualizationType=='hlist' || layout.props.visualizationType=='vlist'){
					/*var isMouseDown = false;
					//for mousedown select track mousedown
					$element.mousedown(function() {
        				isMouseDown = true;
					})
					.mouseup(function() {
						isMouseDown = false;
					});*/
					$element.find( 'li' ).on( 'qv-activate', function (ev) { //mouseenter
						/*if(isMouseDown == false && ev.type=='mouseenter'){
							return;
						}*/
						var klikkauskohde = $(this);
						var kohteenValueID = parseInt(klikkauskohde.attr( "data-value" ),10);
						if (debug) console.log('qv active on list change');
						//var value = parseInt( klikkauskohde.attr( "data-value" ), 10 );

						if (!$(this).hasClass('selected')){
							if (debug) console.log('is selected');
							if (layout.props.selectOnlyOne){
							  if (debug) console.log('removing selections');
							  $element.find( '.selected' ).each(function(){
								var value = parseInt( $(this).attr( "data-value" ), 10 );
								if (value != kohteenValueID){
								  selectValueInQlik(self,value,layout,app,true);
								  $(this).removeClass('selected');
								}
							  });
							}
							selectValueInQlik(self,kohteenValueID,layout,app,true);
							this.classList.toggle("selected");
						//deselect
						} else {
							if (debug) console.log('is not selected');
							klikkauskohde.removeClass('selected');
							selectValueInQlik(self,kohteenValueID,layout,app,true);
							var selectedCount = 0;
							$element.find( '.selected' ).each(function(){
							  selectedCount += 1;
							});
							checkDefaultValueSelection($element,selectedCount,layout,self,app);
						}
					} );
					/*$element.find( 'li' ).on( 'mouseenter', function () {
						if(isMouseDown){
							$(this).trigger('qv-activate');
						}
					});*/
					
				} else
				//select change
				if (layout.props.visualizationType=='dropdown'){
					$element.find( '.dropdownsel' ).on('change',function(){
						if (debug) console.log('select change action');
						var klikkauskohde = $(this).find(":selected");
						var kohteenValueID = parseInt(klikkauskohde.val(),10);
						$element.find( '.selected' ).each(function(){
								var value = parseInt( $(this).val(), 10 );
								if (value != kohteenValueID){
								  //self.backendApi.selectValues( 0, [value], true );
								  selectValueInQlik(self,value,layout,app,true);
								  $(this).removeClass('selected');
								}
						});
						klikkauskohde.addClass('selected').prop('selected',true);
						//self.backendApi.selectValues( 0, [kohteenValueID], true );
						selectValueInQlik(self,kohteenValueID,layout,app,true);
					});
				} else
				//attach click event to checkbox
				if (layout.props.visualizationType=='checkbox'){
				  $element.find( 'input' ).on( 'click', function () {
				  //self.backendApi.clearSelections();
					  if (debug) console.log('checkbox clicked action');
					  var klikkauskohde = $(this);
					  if ( $(this).attr( "data-value" ) ) {
						  var kohteenValueID = parseInt(klikkauskohde.attr( "data-value" ),10);
						  //when checking
						  if ($(this).is(':checked')){
							//if only one, clear others.
							if (layout.props.selectOnlyOne){
								$element.find( 'input:checked' ).each(function(){
									var value = parseInt( $(this).attr( "data-value" ), 10 );
									if (value != kohteenValueID){
									  selectValueInQlik(self,value,layout,app,true);
									  $(this).prop('checked',false).removeClass('selected');
									}
								});
								//or is needed?
								klikkauskohde.prop('checked',true).addClass('selected');
							}
							selectValueInQlik(self,kohteenValueID,layout,app,true);
						  //remove check from box
						  } else {
							  //deselect
							  if (debug) console.log('deseelct');
							  //var value = parseInt( $(this).attr( "data-value" ), 10 );
							  klikkauskohde.prop('checked',false).removeClass('selected');
							  if (debug) console.log(klikkauskohde.attr("data-value"));
							  selectValueInQlik(self,kohteenValueID,layout,app,true);

							  var selectedCount = 0;
							  $element.find( 'input:checked' ).each(function(){
								  selectedCount += 1;
							  });
							  //default selection if needed
							  checkDefaultValueSelection($element,selectedCount,layout,self,app);
						  }
					  }
				  } );
				} else
				//Button action
				if (layout.props.visualizationType=='btn'){
					$element.find( 'button' ).on( 'click', function () {
						if (debug) console.log('Button clicked action');
						var klikkauskohde = $(this);
						if ( $(this).attr( "data-value" ) ) {
							var kohteenValueID = parseInt(klikkauskohde.attr( "data-value" ),10);
							var value = parseInt( klikkauskohde.attr( "data-value" ), 10 );
							selectValueInQlik(self,value,layout,app,true);
						}
					} );
				} //if
				//as default:
				checkDefaultValueSelection($element,countselected,layout,self,app);
			}
			return qlik.Promise.resolve();
		}
	};
} );
