/* to avoid Qlik bug */
define([], function () { return "";});